# HLS and DPU Artifact Evidence Summary

## ONNX validation
- File: `outputs/evidence/onnx_validation.json`
- Result: `onnx_checker` passed
- PyTorch / ONNX numerical agreement: `2.6226043701171875e-06` max absolute error
- Input shape: `[1, 1, 100, 100]`
- Output shape: `[1, 4]`

## Vitis AI quantization metadata
- File: `outputs/real/vai_quant_dpu_stride32/quant_info.json`
- Bias correction: `true`
- Version: `3.5.0+60df3f1+torch1.13.1`
- Parameter scales:
  - `Radar2DCNN::features.0.block.0.weight` and `bias`: `[[8,6]]`
  - `Radar2DCNN::features.2.block.0.weight` and `bias`: `[[8,7]]`
  - `Radar2DCNN::features.4.block.0.weight` and `bias`: `[[8,8]]` / `[[8,7]]`
  - `Radar2DCNN::features.6.block.0.weight` and `bias`: `[[8,8]]` / `[[8,6]]`
  - `Radar2DCNN::classifier_conv.weight`: `[[8,7]]`
  - `Radar2DCNN::classifier_conv.bias`: `[[8,10]]`
- Output tensor scales:
  - `Radar2DCNN::nndct_input_0`: `[[8,6]]`
  - `Radar2DCNN::nndct_relu_2`: `[[8,6]]`
  - `Radar2DCNN::nndct_maxpool_3`: `[[8,6]]`
  - `Radar2DCNN::nndct_relu_5`: `[[8,6]]`
  - `Radar2DCNN::nndct_maxpool_6`: `[[8,6]]`
  - `Radar2DCNN::nndct_relu_8`: `[[8,5]]`
  - `Radar2DCNN::nndct_maxpool_9`: `[[8,5]]`
  - `Radar2DCNN::nndct_avgpool_12`: `[[8,7]]`
  - `Radar2DCNN::nndct_conv2d_13`: `[[8,4]]`

## KV260 compiled model metadata
- Compiled DPU model path: `outputs/real/compiled_kv260_dpu/radar_2dcnn.xmodel`
- DPU metadata file: `outputs/real/compiled_kv260_dpu/meta.json`
  - Library: `libvart-dpu-runner.so`
  - Filename: `radar_2dcnn.xmodel`
  - Kernel list: `subgraph_Radar2DCNN__Radar2DCNN_Conv2d_classifier_conv__ret_27`
  - Target: `DPUCZDX8G_ISA1_B4096`
- Additional model metadata file: `outputs/real/compiled_kv260/meta.json`
  - Library: `libvart-dpu-runner.so`
  - Filename: `radar_2dcnn.xmodel`
  - Kernel list: empty string
  - Target: `DPUCZDX8G_ISA1_B4096`

## HLS fixed-point synthesis summary
- Synthesis report: `hardware/hls/radar_cnn_hls_accel/v2_streaming_v2b/v2_streaming/radar_cnn_stream_prj/solution3_full/syn/report/radar_cnn_stream_full_csynth.rpt`
- Target device: `xck26-sfvc784-2LV-c`
- Target clock: `6.67 ns` (150 MHz)
- Estimated clock period: `4.867 ns`
- Estimated latency: `160054` cycles = `1.067 ms`
- Dataflow initiation interval: `160000` cycles
- Pipeline type: `dataflow`

### Utilization
- BRAM_18K: `57` / `288` = `19%`
- DSP: `1174` / `1248` = `94%`
- FF: `81860` / `234240` = `34%`
- LUT: `113486` / `117120` = `96%`
- URAM: `0` / `64` = `0%`

### Component breakdown highlights
- `stem_conv_stream_U0`: `2` BRAM, `265` DSP, `3302` FF, `14111` LUT
- `depthwise_conv_stream_16_100_100_16_U0`: `231` DSP, `8997` FF, `17746` LUT
- `depthwise_conv_stream_32_50_50_8_U0`: `141` DSP, `8193` FF, `10699` LUT
- `depthwise_conv_stream_64_25_25_8_U0`: `144` DSP, `9343` FF, `11580` LUT
- `depthwise_conv_stream_96_12_12_8_U0`: `144` DSP, `11553` FF, `10752` LUT
- `pointwise_conv_stream_64_96_625_8_4_true_U0`: `32` BRAM, `64` DSP, `4613` FF, `4451` LUT
- `pointwise_conv_stream_96_128_144_8_2_true_U0`: `16` BRAM, `32` DSP, `4802` FF, `3046` LUT
- `gap_stream_128_144_8_U0`: `1` BRAM, `9` DSP, `8458` FF, `4898` LUT

### FIFO summary
- Total FIFO usage: `4` BRAM, `1636` FF, `1101` LUT
- Main FIFO names and depth:
  - `input_pixels_U`: depth `64`, bits `16`, size `1024`
  - `dw1_pixels_U`: depth `4`, bits `256`, size `1024`
  - `dw2_pixels_U`: depth `4`, bits `512`, size `2048`
  - `dw3_pixels_U`: depth `4`, bits `1024`, size `4096`
  - `dw4_pixels_U`: depth `4`, bits `1536`, size `6144`
  - `gap_pixels_U`: depth `2`, bits `2048`, size `4096`
  - `logit_pixels_U`: depth `2`, bits `64`, size `128`
  - `logits_c_U`: depth `17`, bits `64`, size `1088`

## HLS host-float validation
- Validation file: `outputs/evidence/hls_validation_status.md`
- Status: all classes passed
- Maximum absolute logit error by class:
  - Drone: `4.17e-7`
  - Bird: `8.94e-7`
  - Human: `3.58e-7`
  - CornerReflector: `3.13e-7`

## Training and evaluation evidence
- Already captured in `report_evidence/training_evaluation_summary.md`
- Includes final model selection, class weights, training hyperparameters, and human-readable host/DPU test metrics

## Notes
- The DPU artifact is validated through metadata and subgraph mapping on `DPUCZDX8G_ISA1_B4096`.
- The HLS synthesis report is the source of the fixed-point resource and timing estimates.
- Existing evidence artifacts in `outputs/evidence/` should be referenced directly for validation details.
