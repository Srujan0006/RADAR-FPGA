# Report Fill Guide

This guide maps the key audit evidence files to report sections and findings.

## Core evidence files

- `report_evidence/report_values.json`
  - Structured numeric evidence for ONNX validation, quantization, compiled DPU metadata, HLS synthesis estimates, and training/test metrics.

- `report_evidence/hls_and_dpu_artifact_summary.md`
  - Human-readable summary of the main artifacts and exact values extracted from the repo.

- `report_evidence/training_evaluation_summary.md`
  - Training selection metadata, model architecture, preprocessing, split strategy, and host/DPU evaluation metrics.

## Direct artifact sources

- `outputs/evidence/onnx_validation.json`
  - ONNX checker status and PyTorch/ONNX agreement.

- `outputs/real/vai_quant_dpu_stride32/quant_info.json`
  - Vitis AI quantization parameter scales, output scales, and bias correction.

- `outputs/real/compiled_kv260_dpu/meta.json`
  - Compiled KV260 xmodel metadata, kernel mapping, and DPU target.

- `outputs/real/compiled_kv260/meta.json`
  - Alternate compiled xmodel metadata.

- `hardware/hls/radar_cnn_hls_accel/v2_streaming_v2b/v2_streaming/radar_cnn_stream_prj/solution3_full/syn/report/radar_cnn_stream_full_csynth.rpt`
  - Fixed-point HLS synthesis report with timing and resource estimates.

- `outputs/evidence/hls_validation_status.md`
  - Host-float HLS validation results against current PyTorch checkpoint.

- `outputs/real/train_max_stride32_4class_dpu/test_metrics.json`
  - DPU-friendly model test metrics and confusion matrix.

## Supporting source and design context

- `hardware/hls/radar_cnn_hls_accel/v2_streaming_v2b/v2_streaming/radar_cnn_stream.h`
  - HLS fixed-point data types and the complete proven streaming CNN architecture.

- `hardware/hls/radar_cnn_hls_accel/v2_streaming_v2b/v2_streaming/README.md`
  - V2 streaming accelerator status, verification history, and architecture summary.

- `outputs/final_model/train_config.json`
  - Final selected model configuration and training provenance.

- `README.md`
  - High-level repository deployment and DPU/HLS path documentation.

## Notes for report writing

- Use `report_values.json` for exact numeric figures and `hls_and_dpu_artifact_summary.md` for prose-ready evidence descriptions.
- The HLS report proves the custom accelerator fits the K26 device at 150 MHz with 96% LUT and 94% DSP utilization.
- The compiled KV260 DPU artifact is confirmed on `DPUCZDX8G_ISA1_B4096` with the main CNN subgraph mapped to DPU.
- The ONNX validation and HLS host-float checks provide independent consistency evidence for the model and accelerator.
