# Training and Evaluation Evidence

## Final selected model
- `outputs/final_model/train_config.json`
- Selected checkpoint: `outputs/final_model/radar_dscnn2d_topk3_capped8_best.pth`
- Selection criterion: `validation_macro_f1`
- Best epoch: `35`
- Best validation macro F1: `0.7839002267573696`

## Model architecture and preprocessing
- Architecture: `radar_dscnn2d`
- Input shape: `[1, 100, 100]`
- Number of classes: `4`
- Class names: `Drone`, `Bird`, `Human`, `CornerReflector`
- Preprocessing: `range_mode = topk_energy_mean`
- Top-K range selection: `3`
- Spectrogram image size: `100`
- Window length: `256`
- Stride: `32`

## Train/validation/test split
- Split strategy: `grouped_stratified_recording_rows`
- Ratios: `train 0.7`, `validation 0.15`, `test 0.15`
- Seed: `42`
- Recording row overlap: `0`

## Training hyperparameters
- Augmentation: `RadarSpecAugment_train_only`
- Imbalance strategy: `capped`
- Max class weight: `8.0`
- Class weights: `[0.2838594704684318, 4.569672131147541, 4.35546875, 8.0]`
- Optimizer: `AdamW`
- Learning rate: `0.001`
- Weight decay: `0.0001`
- Batch size: `32`
- Epochs requested: `100`
- Epochs completed: `47`
- Early stopping patience: `12`
- Scheduler: `ReduceLROnPlateau`
- Scheduler patience: `8`
- Checkpoint metric: `validation_macro_f1`

## Evaluation metrics
- `outputs/real/train_max_4class/test_metrics.json`
  - `test_loss`: `1.3259040514628093`
  - `test_accuracy`: `0.855072463768116`
  - Class support: `Drone 59`, `Bird 4`, `Human 5`, `CornerReflector 1`
  - Macro F1: `0.3968` (from classification report)
  - Weighted accuracy: `0.8551`

- `outputs/real/train_max_stride32_4class_dpu/test_metrics.json`
  - `test_loss`: `0.12305028331192101`
  - `test_accuracy`: `0.9693486590038314`
  - Class support: `Drone 230`, `Bird 12`, `Human 18`, `CornerReflector 1`
  - Macro F1: `0.9254` (from classification report)
  - Weighted accuracy: `0.9698`

## Notes
- The chosen final model uses the capped class-weight strategy and a stride of 32.
- Evaluation metrics are available for both the host training run and the KV260 DPU inference run.
